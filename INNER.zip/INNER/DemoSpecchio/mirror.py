import actr
import pyttsx3
#from naoqi import ALProxy

actr.load_act_r_model("ACT-R:INNER;DemoSpecchio;mirror.lisp")

global response, response_time
response = ''
response_time = False

def record_model_speech (model, string):
    global response,response_time
    #response_time = actr.get_time(True)
    response = string
    speech(response)
   
def speech(response):
    engine = pyttsx3.init()
    engine.setProperty('rate', 125) 
    engine.say(response)
    engine.runAndWait()
    engine.stop()


def demo_mirror() :
    actr.reset()
    actr.add_command("inner-speech-response",record_model_speech, "Inner speech model response")
    actr.monitor_command("output-speech", "inner-speech-response")
    actr.install_device(["speech","microphone"])
    actr.run(50)
    actr.remove_command_monitor("output-speech","inner-speech-response")
    actr.remove_command("inner-speech-response")
    #actr.set_parameter_value(":show-audicon-history", True)
    

def AL_tts():
    IP = "192.168.0.2"
    tts = ALProxy("ALTextToSpeech", IP, 9559)
    tts.say("Hello my name is Pepper")

#AL_tts()
demo_mirror()
