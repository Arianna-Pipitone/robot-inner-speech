import actr
import pyttsx3

actr.load_act_r_model("ACT-R:INNER;v0.2;inner_model.lisp")

response = False
response_time = False


def sentence (verb, object):

    actr.reset()

    window = actr.open_exp_window("Inner Speech Demo")
    actr.install_device(window)
    actr.add_text_to_exp_window(window, verb)
    actr.add_text_to_exp_window(window, object)

    actr.add_command("key-press-response",respond_to_key_press, "Modeling key press response")
    actr.monitor_command("output-key","key-press-response")

    actr.add_command("inner-speech-response",record_model_speech, "Inner speech model response")
    actr.monitor_command("output-speech","inner-speech-response")


    actr.run(30)

    actr.remove_command_monitor("output-speech","inner-speech-response")
    actr.remove_command("inner-speech-response")
    actr.remove_command_monitor("output-key","key-press-response")
    actr.remove_command("key-press-response")

def respond_to_key_press (model,key):
    global response,response_time

    response_time = actr.get_time(False)
    response = key

def record_model_speech (model,string):
    global response,response_time

    response_time = actr.get_time(True)
    response = string
    print (response)
    engine = pyttsx3.init()
    engine.say(response)
    #engine.runAndWait()
    engine.stop()