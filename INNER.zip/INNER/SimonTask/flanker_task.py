import actr
from random import *
import numpy as np
import matplotlib.pyplot as plt
import csv
import seaborn as sns
import pandas as pd
import warnings

actr.load_act_r_model ("ACT-R:INNER;SimonTask;inner_model2.lisp")

window = None
visible = True
current_shape = None
congruent=0
incongruent=0
correct=0
incorrect=0
max_trials = 3
participants = 1
id_trial = 0
exp_data = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
general_rt = []
congruent_rt = []
incongruent_rt = []
dataset_rt = [["General RT", "Congruent Par", "Incongruent Par", "Conflict"]]
response_time = False
conflict = False
congruent_correct = 0
incongruent_correct = 0
flag = True #to flag a correct choice in a trial


def build_display ():
    global window, exp_data, id_trial
    actr.reset()
    window = actr.open_exp_window("Solving Flanker Task",visible=visible,width=800,height=550)
    actr.add_text_to_exp_window(window,'+', x=370, y=200, color='black', width=50, font_size=50)
    actr.add_button_to_exp_window(window, text="A", x=70, y=450, action=["button-pressed","left"], height=50, width=80)
    actr.add_button_to_exp_window(window, text="B", x=650, y=450, action=["button-pressed","right"], height=50, width=80)
    actr.install_device(window)
    actr.print_visicon()
    
def button_pressed(button):
    global window,data_trial, congruent, incongruent, correct, incorrect, current_shape, response_time, conflict, incongruent_correct, congruent_correct
    response_time = actr.get_time()
    flag = True
    conflict = False
    if (button == "left") and (data_trial[0] == 1) :
        congruent+=1
        correct+=1
        congruent_correct += 1
    elif button == 'left' and data_trial[1] == 1 :
        incongruent+=1
        correct+=1
        conflict = True
        incongruent_correct += 1
    elif button == 'right' and data_trial[2] == 1 :
        incongruent+=1
        correct+=1
        conflict = True
        incongruent_correct += 1
    elif button == 'right' and data_trial[3] == 1 :
        congruent+=1
        correct+=1
        congruent_correct += 1
    else :
        incorrect+=1
        flag = False
    
    print(correct, incorrect)
    
    current_shape = None

actr.add_command("button-pressed", button_pressed, "Choice button action for the Simon Task.  Do not call directly")
  
def run_trial() :
    global window, id_trial, exp_data, data_trial, current_shape, flag, response_time, correct
    time = 0
    clear_display_for_trial()
    data_trial = exp_data[id_trial]
    start = actr.get_time()
    #data_trial = actr.permute_list(data_trial)
    #print(data_trial)
    if data_trial[0] == 1 :
        current_shape = actr.create_image_for_exp_window(window,"round",'flanker_A.gif', x=70, y=140 ,height=122,width=681)
        actr.add_items_to_exp_window(window, current_shape)
    elif data_trial[1] == 1 :
        current_shape = actr.create_image_for_exp_window(window,'round','flanker_B.gif', x=95, y=130 ,height=122,width=681)
        actr.add_items_to_exp_window(window, current_shape)
    elif data_trial[2] == 1:
        current_shape = actr.create_image_for_exp_window(window, 'diamond','flanker_C.gif', x=80, y=140 ,height=122,width=681)
        actr.add_items_to_exp_window(window, current_shape)
    elif data_trial[3] == 1:
        current_shape = actr.create_image_for_exp_window(window,'diamond','flanker_D.gif', x=80, y=140 ,height=122,width=681)
        actr.add_items_to_exp_window(window, current_shape)
        
    actr.run(20, visible)
    
    if (flag) and (correct!=0):
        time += response_time - start
        rt = time / correct / 1000.0
        if conflict :
            incongruent_rt.append(rt)
        else:
            congruent_rt.append(rt)
        general_rt.append(rt)
        
  
def clear_display_for_trial():
    global window, num_trial
    actr.clear_exp_window(window)
    #actr.add_text_to_exp_window(window, 'Trial number '+str(num_trial), x=10, y = 10, color ='black')
    #actr.add_text_to_exp_window(window,'+', x=370, y=200, color='black', width=50, font_size=50)
    actr.add_button_to_exp_window(window, text="A", x=70, y=450, action=["button-pressed","left"], height=50, width=80)
    actr.add_button_to_exp_window(window, text="B", x=650, y=450, action=["button-pressed","right"], height=50, width=80)

def compute_coefficient_rt():
    global general_rt, congruent_rt, incongruent_rt, dataset_rt
    general_coeff = np.mean(general_rt)
    if (len(congruent_rt)!=0):
        congruent_coeff = np.mean(congruent_rt)
    else : congruent_coeff = 0
    if (len(incongruent_rt)!=0):
        incongruent_coeff = np.mean(incongruent_rt)
    else : incongruent_coeff = 0
    conflict_coeff = congruent_coeff-incongruent_coeff
    dataset_rt.append([general_coeff, congruent_coeff, incongruent_coeff, conflict_coeff])
    #dataset_rt.append([general_coeff, conflict_coeff])
    print(dataset_rt)
    
def create_response_time_csv () :
    global dataset_rt
    with open('response_time.csv', mode='w', newline='') as response_time_csv:
        response_time_writer = csv.writer(response_time_csv)
        for data in dataset_rt:
            response_time_writer.writerow(data)
            
            

def plot_response_times():
    sns.set()
    rt_dataset = pd.read_csv("response_time.csv")
    sns.boxplot(x="Conflict", y="General RT", data=rt_dataset)
    plt.grid(True)
    plt.show()
##    plt.plot([times[0][0]*100, times[0][3]], '-', color='black', linewidth=0.5)
##    plt.plot([times[0][0]*100, times[0][3]], 's', mfc='white', color='black')
##    plt.plot([544, 6], '-', color='black', linewidth=0.5)
##    plt.plot([544, 6], 's', mfc='white', color='black')
##    plt.ylabel('Response Time (ms)')
##    plt.xlabel('Coefficients')
   

def compute_error_rate():
    result=[]
    global correct, incorrect, congruent_correct, incongruent_correct, max_trials
    error_congruent = congruent_correct/max_trials
    error_incongruent = incongruent_correct/max_trials
    abs_correct = (congruent_correct + incongruent_correct)/max_trials
    result.append((error_congruent, error_incongruent, abs_correct))
    print(result)
    
   
def start_block(trials) :
    global id_trial, num_trial, result
    build_display()
    result = []
    for i in range(trials):
        num_trial = i + 1
        id_trial = randint(0, 3)
        run_trial()
    
    compute_coefficient_rt()
    compute_error_rate()

for i in range (participants) :
    start_block(max_trials)
create_response_time_csv()
plot_response_times()
