import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt
from scipy import stats

sns.set(color_codes=True)

plt.figure(figsize=(7, 5.5))
#df = pd.read_csv('GadeSimonERComp.csv', delim_whitespace=True)
df = pd.read_csv('GadeSimonERComp.csv', sep=';')
ER_con = df[['participant', 'ER_con']]
#ERROR RATE CON
df_chart = sns.scatterplot(x="ER_con", y = "participant", hue ="origin", palette=["r", "c"], data=df)
plt.xlabel('Error Rate - Congruent Trials', fontsize=10)
plt.ylabel('ID partecipant', fontsize=10)
plt.title("Simon Task - Error Rate Distribution over Participants aggregated for Congruent Trials")
plt.show()

#ERROR RATE INCON
df_chart = sns.scatterplot(x="ER_incon", y = "participant", hue ="origin", palette=["r", "c"], data=df)
plt.xlabel('Error Rate - Incongruent Trials', fontsize=10)
plt.ylabel('ID partecipant', fontsize=10)
plt.title("Simon Task - Error Rate Distribution over Participants aggregated for Incongruent Trials")
plt.show()

#ABS CON
df_chart = sns.scatterplot(x="abs_con", y = "participant", hue ="origin",  palette=["r", "c"], data=df)
#sns.pairplot(df)
#sns.relplot(x="ER_con", y="participant", dashes=False, markers=True, kind="line", data=ER_con)
plt.xlabel('Absolute Value - Congruent Trials', fontsize=10)
plt.ylabel('ID partecipant', fontsize=10)
plt.title("Simon Task - Absolute Value over Participants aggregated for Congruent Trials")
plt.show()

#ABS INCON
df_chart = sns.scatterplot(x="abs_incon", y = "participant", hue ="origin", palette=["r", "c"], data=df)
#sns.pairplot(df)
#sns.relplot(x="ER_con", y="participant", dashes=False, markers=True, kind="line", data=ER_con)
plt.xlabel('Absolute Value - Incongruent Trials', fontsize=10)
plt.ylabel('ID partecipant', fontsize=10)
plt.title("Simon Task - Absolute Value over Participants aggregated for Incongruent Trials")
plt.show()

#MEAN CON
df_chart = sns.scatterplot(x="mean_con", y = "participant", hue ="origin", palette=["r", "c"], data=df)
#sns.pairplot(df)
#sns.relplot(x="ER_con", y="participant", dashes=False, markers=True, kind="line", data=ER_con)
plt.xlabel('Mean - Congruent Trials', fontsize=10)
plt.ylabel('ID partecipant', fontsize=10)
plt.title("Simon Task - Mean Value over Participants aggregated for Congruent Trials")
plt.show()

#MEAN INCON
df_chart = sns.scatterplot(x="mean_incon", y = "participant", hue ="origin", palette=["r", "c"], data=df)
#sns.pairplot(df)
#sns.relplot(x="ER_con", y="participant", dashes=False, markers=True, kind="line", data=ER_con)
plt.xlabel('Mean - Incongruent Trials', fontsize=10)
plt.ylabel('ID partecipant', fontsize=10)
plt.title("Simon Task - Mean Value over Participants aggregated for Incongruent Trials")
plt.show()
