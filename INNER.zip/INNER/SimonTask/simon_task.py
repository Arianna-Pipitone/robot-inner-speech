import actr
from random import *

actr.load_act_r_model ("ACT-R:INNER;SimonTask;inner_model2.lisp")
window = None
visible = True
current_shape = None
congruent=0
incongruent=0
correct=0
incorrect=0
max_trial = 192
id_trial = 0
num_trial = 0
exp_data = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
#data_trial = [1, 0, 0, 0]
#data_trial = [0, 0, 0, 0]
flag = 0


def build_display ():
    global window, exp_data, id_trial
    actr.reset()
    window = actr.open_exp_window("Solving Simon Task",visible=visible,width=800,height=550)
    actr.add_text_to_exp_window(window,'+', x=370, y=200, color='black', width=50, font_size=50)
    actr.add_button_to_exp_window(window, text="A", x=70, y=450, action=["button-pressed","left"], height=50, width=80)
    actr.add_button_to_exp_window(window, text="B", x=650, y=450, action=["button-pressed","right"], height=50, width=80)
    actr.install_device(window)
    actr.print_visicon()
    
def button_pressed(button):
    global window,data_trial, congruent, incongruent, correct, incorrect, current_shape

    if (button == "left") and (data_trial[0] == 1) :
        congruent+=1
        correct+=1
    elif button == 'left' and data_trial[1] == 1 :
        incongruent+=1
        correct+=1
    elif button == 'right' and data_trial[2] == 1 :
        incongruent+=1
        correct+=1
    elif button == 'right' and data_trial[3] == 1 :
        congruent+=1
        correct+=1
    else : incorrect+=1

    print(correct, incorrect)

    current_shape = None

actr.add_command("button-pressed", button_pressed, "Choice button action for the Simon Task.  Do not call directly")


    
def run_trial() :
    global window, id_trial, exp_data, data_trial, current_shape, flag

    clear_display_for_trial()
    data_trial = exp_data[id_trial]
    #data_trial = actr.permute_list(data_trial)
    #print(data_trial)
    if data_trial[0] == 1 :
        current_shape = actr.create_image_for_exp_window(window,"round",'Quadrato-Nero.gif', x=120, y=140 ,height=141,width=141)
        actr.add_items_to_exp_window(window, current_shape)
        flag = 1
    elif data_trial[1] == 1 :
        current_shape = actr.create_image_for_exp_window(window,'round','Quadrato-Nero.gif', x=560, y=140, height=141,width=141)
        actr.add_items_to_exp_window(window, current_shape)
        flag = 2
    elif data_trial[2] == 1:
        current_shape = actr.create_image_for_exp_window(window, 'diamond','Rombo-Nero.gif', x=100, y=120, height=200,width=200)
        actr.add_items_to_exp_window(window, current_shape)
        flag = 3
    else :
        current_shape = actr.create_image_for_exp_window(window,'diamond','Rombo-Nero.gif', x=560, y=120, height=200,width=200)
        actr.add_items_to_exp_window(window, current_shape)
        flag = 4
    actr.run(20, visible)

def clear_display_for_trial():
    global window, num_trial
    
    actr.clear_exp_window()
    #actr.add_text_to_exp_window(window, 'Trial number '+str(num_trial), x=10, y = 10, color ='black')
    actr.add_text_to_exp_window(window,'+', x=370, y=200, color='black', width=50, font_size=50)
    actr.add_button_to_exp_window(window, text="A", x=70, y=450, action=["button-pressed","left"], height=50, width=80)
    actr.add_button_to_exp_window(window, text="B", x=650, y=450, action=["button-pressed","right"], height=50, width=80)
   
   
def start_block() :
    global id_trial, num_trial
    build_display()
    for i in range(3):
        num_trial = i + 1
        id_trial = randint(0, 3)
        run_trial()
#build_display()
#run_trial()
start_block()
