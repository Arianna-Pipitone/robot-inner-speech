import actr
import pyttsx3
from nltk.tokenize import word_tokenize
import speech_recognition as sr

actr.load_act_r_model("ACT-R:INNER;v0.5;inner_model.lisp")


response = False
response_time = False

def speech_recognition() :
    actr.reset()
    string = "ciao"
    print(string)
    # obtain audio from the microphone
    r = sr.Recognizer()
    with sr.Microphone() as source:
        r.adjust_for_ambient_noise(source)
        print("Say something!")
        audio = r.listen(source)
        text = r.recognize_google(audio, language="it-IT")
        text = word_tokenize(text)
    # recognize speech using Google Speech Recognition
    try:
    # for testing purposes, we're just using the default API key
    # to use another API key, use `r.recognize_google(audio, key="GOOGLE_SPEECH_RECOGNITION_API_KEY")`
    # instead of `r.recognize_google(audio)`
        print("Google Speech Recognition thinks you said " + str(text))
    except sr.UnknownValueError:
        print("Google Speech Recognition could not understand audio")
    except sr.RequestError as e:
        print("Could not request results from Google Speech Recognition service; {0}".format(e))
    #actr.new_word_sound(text)
    for word in text:
        actr.new_word_sound(word)
    actr.run(30)

def sentence (verb, object):

    actr.reset()

    window = actr.open_exp_window("Inner Speech Demo")
    actr.install_device(window)
    actr.add_text_to_exp_window(window, verb)
    actr.add_text_to_exp_window(window, object)

    actr.add_command("key-press-response",respond_to_key_press, "Modeling key press response")
    actr.monitor_command("output-key","key-press-response")

    actr.add_command("inner-speech-response",record_model_speech, "Inner speech model response")
    actr.monitor_command("output-speech","inner-speech-response")


    actr.run(30)

    actr.remove_command_monitor("output-speech","inner-speech-response")
    actr.remove_command("inner-speech-response")
    actr.remove_command_monitor("output-key","key-press-response")
    actr.remove_command("key-press-response")

def respond_to_key_press (model,key):
    global response,response_time

    response_time = actr.get_time(False)
    response = key

def record_model_speech (model,string):
    global response,response_time

    response_time = actr.get_time(True)
    response = string
    print (response)
    engine = pyttsx3.init()
    engine.say(response)
    engine.runAndWait()
    engine.stop()